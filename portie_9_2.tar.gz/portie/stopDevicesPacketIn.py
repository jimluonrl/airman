#stopDevicesPacketIn.py
from airs_config import getArg, base_url, ifile, ofile, ethTypes, priority, timeout, restUser, restPassword, nrlAppId


import airs_config 
import sys
import makeDropRules
import airs_flows


def stopPacketIn():
    getArg(sys.argv[1:])

    makeDropRules.buildInputFile(base_url, ethTypes, priority, timeout, ifile)
    makeDropRules.py2Json(makeDropRules.buildDropFlows(ifile), ofile)
    airs_flows.post_flows(base_url, ofile)
  
if __name__ == '__main__':

   stopPacketIn()
