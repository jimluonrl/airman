#stopDevicesPacketIn.py

import makeDropRules
import airs_flows

ifile = "input.Json"
ofile = "output.Json"
ethTypes = ['0x8cc', '0x806', '0x800']
priority = 100
timeout = 600

def removeStopPacketIn(base_url):
    airs_flows.clear_flowsByAppId(base_url, 'nrl.airman.stop_packetin')
  
if __name__ == '__main__':

    base_url= 'http://karaf:karaf@192.168.80.90:8181/onos/v1/'
    removeStopPacketIn(base_url)
