#airs_config.py

import sys, getopt

ifile = "input.Json"
ofile = "output.Json"
ethTypes = ['0x8cc', '0x806', '0x800']
priority = 100
nrlAppId = "nrl.airman.app"

timeout = 600

restUser = 'karaf'
restPassword = 'karaf'

base_url = 'http://192.168.80.90:8181/onos/v1/'

def getArg(argv):
   global base_url, timeout, restUser, restPassword
   
   try:
      opts, args = getopt.getopt(argv,"hb:u:p:t:",[])
   except getopt.GetoptError:
      print('test.py -i <inputfile> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print('usage -b <baseURL> -u <restUser> -p <restpassword> -t <timeout>')
         sys.exit()
      elif opt in ("-b"):
         base_url = arg
      elif opt in ("-u"):
         restUser = arg
      elif opt in ("-p"):
         restPassword = arg
      elif opt in ("-t"):
         timeout = int(float(arg))

   print('Base url is: ', base_url)
   print('Rest user is: ', restUser)
   print('Rest password is: ', restPassword)
   print('Timeout is: ', timeout)

if __name__ == "__main__":
   getArg(sys.argv[1:])