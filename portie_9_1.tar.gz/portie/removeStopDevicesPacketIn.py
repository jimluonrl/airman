#stopDevicesPacketIn.py
from airs_config import getArg, base_url, ifile, ofile, ethTypes, priority, timeout, restUser, restPassword, nrlAppId

import makeDropRules
import airs_flows

def removeStopPacketIn():
    getArg(sys.argv[1:])
    airs_flows.clear_flowsByAppId(base_url, nrlAppId)
  
if __name__ == '__main__':
    removeStopPacketIn()
